import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
from xgboost import XGBRegressor

DATA_FILE = "mec_sample_data.csv"
MODEL_FILE = "h2_model.json"

FEATURES = ["pH", "temperature_C", "voltage_V", "COD_mg_L", "current_A"]
TARGET = "H2_mL"

df = pd.read_csv(DATA_FILE)

X = df[FEATURES]
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

model = XGBRegressor(
    n_estimators=300,
    max_depth=4,
    learning_rate=0.04,
    subsample=0.9,
    colsample_bytree=0.9,
    objective="reg:squarederror",
    random_state=42
)

model.fit(X_train, y_train)

pred = model.predict(X_test)
mae = mean_absolute_error(y_test, pred)
r2 = r2_score(y_test, pred)

model.save_model(MODEL_FILE)

print(f"Model saved to {MODEL_FILE}")
print(f"Test MAE: {mae:.2f} mL")
print(f"Test R2: {r2:.3f}")
