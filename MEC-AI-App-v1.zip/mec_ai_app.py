
import os
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
from xgboost import XGBRegressor

st.set_page_config(page_title="MEC-AI", page_icon="⚡", layout="centered")

DATA_FILE = "mec_sample_data.csv"
MODEL_FILE = "h2_model.json"
FEATURES = ["pH", "temperature_C", "voltage_V", "COD_mg_L", "current_A"]

@st.cache_data
def load_data():
    return pd.read_csv(DATA_FILE)

@st.cache_resource
def get_model():
    model = XGBRegressor(
        n_estimators=300, max_depth=4, learning_rate=0.04,
        subsample=0.9, colsample_bytree=0.9,
        objective="reg:squarederror", random_state=42
    )
    if os.path.exists(MODEL_FILE):
        model.load_model(MODEL_FILE)
    else:
        df = load_data()
        model.fit(df[FEATURES], df["H2_mL"])
        model.save_model(MODEL_FILE)
    return model

df = load_data()
model = get_model()

# ---------- Styling ----------
st.markdown("""
<style>
.block-container {max-width: 760px; padding-top: 1rem; padding-bottom: 2rem;}
.hero {
    padding: 22px; border-radius: 22px;
    background: linear-gradient(135deg, #0f172a, #164e63);
    color: white; margin-bottom: 16px;
}
.hero h1 {margin: 0; font-size: 2rem;}
.hero p {margin: 7px 0 0; opacity: .85;}
.card {
    padding: 16px; border-radius: 18px;
    border: 1px solid rgba(128,128,128,.25);
    margin-bottom: 12px;
}
.big {font-size: 2rem; font-weight: 700;}
.small {opacity: .7; font-size: .85rem;}
.ok {padding: 10px 14px; border-radius: 12px; background: rgba(34,197,94,.12);}
.warn {padding: 10px 14px; border-radius: 12px; background: rgba(234,179,8,.14);}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
<h1>⚡ MEC-AI</h1>
<p>AI-powered hydrogen production & wastewater monitoring</p>
</div>
""", unsafe_allow_html=True)

# ---------- Navigation ----------
tab1, tab2, tab3 = st.tabs(["🏠 Dashboard", "🤖 AI Optimize", "📊 Analytics"])

# ---------- Dashboard ----------
with tab1:
    st.subheader("Live MEC Status")

    c1, c2 = st.columns(2)
    with c1:
        ph = st.number_input("pH", min_value=5.0, max_value=9.0, value=6.8, step=0.1)
        temp = st.number_input("Temperature (°C)", min_value=20.0, max_value=50.0, value=35.0, step=0.5)
        voltage = st.number_input("Voltage (V)", min_value=0.1, max_value=1.2, value=0.70, step=0.01)
    with c2:
        cod = st.number_input("COD (mg/L)", min_value=100, max_value=1500, value=550, step=10)
        current = st.number_input("Current (A)", min_value=0.05, max_value=1.0, value=0.45, step=0.01)

    inp = pd.DataFrame({
        "pH":[ph], "temperature_C":[temp], "voltage_V":[voltage],
        "COD_mg_L":[cod], "current_A":[current]
    })
    h2 = float(model.predict(inp)[0])

    optimal = 6.5 <= ph <= 7.0 and 0.2 <= voltage <= 0.8
    status = "OPTIMAL" if optimal else "CHECK CONDITIONS"

    a, b, c = st.columns(3)
    a.metric("Predicted H₂", f"{h2:.1f} mL")
    b.metric("MEC Status", status)
    c.metric("Voltage", f"{voltage:.2f} V")

    if optimal:
        st.markdown('<div class="ok">🟢 Operating conditions are inside the demo target range.</div>', unsafe_allow_html=True)
    else:
        st.markdown('<div class="warn">🟡 AI recommends checking the operating conditions.</div>', unsafe_allow_html=True)

    st.subheader("Current Parameters")
    st.dataframe(inp.T.rename(columns={0:"Value"}), use_container_width=True)

# ---------- Optimization ----------
with tab2:
    st.subheader("🎯 AI Optimization")
    st.write("Find a pH and voltage combination predicted to increase H₂ production while holding your current temperature, COD and current constant.")

    temp2 = st.slider("Temperature (°C)", 25.0, 42.0, 35.0, 0.5, key="t2")
    cod2 = st.slider("COD (mg/L)", 300, 900, 550, 10, key="c2")
    current2 = st.slider("Current (A)", 0.10, 0.60, 0.45, 0.01, key="i2")

    best_h2 = -1
    best = None

    for p in np.arange(6.5, 7.01, 0.1):
        for v in np.arange(0.2, 0.801, 0.02):
            candidate = pd.DataFrame({
                "pH":[round(p,2)], "temperature_C":[temp2],
                "voltage_V":[round(v,2)], "COD_mg_L":[cod2],
                "current_A":[current2]
            })
            pred = float(model.predict(candidate)[0])
            if pred > best_h2:
                best_h2, best = pred, candidate.iloc[0]

    r1, r2 = st.columns(2)
    r1.metric("Recommended pH", f"{best['pH']:.1f}")
    r2.metric("Recommended Voltage", f"{best['voltage_V']:.2f} V")

    r3, r4 = st.columns(2)
    r3.metric("Temperature", f"{best['temperature_C']:.1f} °C")
    r4.metric("Predicted H₂", f"{best_h2:.1f} mL")

    st.success("AI recommendation generated from the demo model.")

    st.warning("Demo only: the included training data is synthetic. Do not use these recommendations to control real MEC hardware until the model is trained and validated on experimental data.")

# ---------- Analytics ----------
with tab3:
    st.subheader("📊 MEC Analytics")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["voltage_V"], y=df["H2_mL"],
        mode="markers", text=df["pH"].round(2),
        hovertemplate="Voltage: %{x:.2f} V<br>H₂: %{y:.1f} mL<br>pH: %{text}<extra></extra>"
    ))
    fig.update_layout(
        title="Voltage vs Predicted/Measured Demo H₂",
        xaxis_title="Voltage (V)", yaxis_title="H₂ (mL)",
        height=380
    )
    st.plotly_chart(fig, use_container_width=True)

    importance = pd.DataFrame({
        "Parameter": FEATURES,
        "Importance": model.feature_importances_
    }).sort_values("Importance", ascending=True)

    fig2 = go.Figure(go.Bar(
        x=importance["Importance"],
        y=importance["Parameter"],
        orientation="h"
    ))
    fig2.update_layout(title="AI Feature Importance", height=360)
    st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Sample Data")
    st.dataframe(df.head(20), use_container_width=True)

st.caption("MEC-AI prototype • Built for demonstration and SIH prototyping")
