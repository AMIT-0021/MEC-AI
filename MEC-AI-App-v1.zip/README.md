# MEC AI Streamlit Dashboard

## What it does
- Predicts H2 production using XGBoost.
- Displays MEC operating inputs.
- Shows feature importance and charts.
- Searches a pH/voltage grid for a predicted high-H2 operating point.
- Includes sample MEC data.

## Important
The included dataset is synthetic demo data. Replace it with experimentally measured MEC data before making scientific or hardware-control claims.

## Run on Windows

1. Open Command Prompt in this folder.
2. Install dependencies:
   `pip install -r requirements.txt`
3. Start the dashboard:
   `streamlit run app.py`

The browser should open automatically. If not, Streamlit will print a local address.

Optional:
`python train_model.py`

Then:
`streamlit run app.py`
