# MEC-AI App — Version 1

## Run
1. Install Python 3.10+.
2. Extract this folder.
3. Double-click `RUN_MEC_AI.bat`, or run:
   `pip install -r requirements.txt`
   `streamlit run mec_ai_app.py`

## App features
- Mobile-style MEC dashboard
- H2 prediction using XGBoost
- pH, temperature, voltage, COD and current inputs
- AI optimization of pH and voltage
- Analytics charts
- Feature importance
- Sample MEC dataset

## Important
The dataset supplied with this prototype is synthetic demonstration data. The AI predictions/recommendations must not be treated as validated scientific results or used to control real hardware until trained and validated on experimental MEC data.
