@echo off
echo Installing MEC-AI requirements...
python -m pip install -r requirements.txt
echo.
echo Starting MEC-AI...
streamlit run mec_ai_app.py
pause
