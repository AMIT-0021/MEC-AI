import os
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

st.set_page_config(
    page_title="MEC AI Control Dashboard",
    page_icon="⚡",
    layout="wide"
)

DATA_FILE = "mec_sample_data.csv"
MODEL_FILE = "h2_model.json"
FEATURES = ["pH", "temperature_C", "voltage_V", "COD_mg_L", "current_A"]

@st.cache_data
def load_data():
    return pd.read_csv(DATA_FILE)

@st.cache_resource
def load_model():
    model = XGBRegressor(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.04,
        subsample=0.9,
        colsample_bytree=0.9,
        objective="reg:squarederror",
        random_state=42
    )
    if os.path.exists(MODEL_FILE):
        model.load_model(MODEL_FILE)
    else:
        df = load_data()
        X = df[FEATURES]
        y = df["H2_mL"]
        model.fit(X, y)
        model.save_model(MODEL_FILE)
    return model

df = load_data()
model = load_model()

st.title("⚡ MEC AI — Hydrogen Production & Wastewater Monitoring")
st.caption("Demo dashboard: XGBoost prediction + operating-condition recommendation")

with st.sidebar:
    st.header("MEC Operating Inputs")
    ph = st.slider("pH", 6.0, 7.5, 6.8, 0.1)
    temp = st.slider("Temperature (°C)", 25.0, 42.0, 35.0, 0.5)
    voltage = st.slider("Applied Voltage (V)", 0.2, 0.8, 0.70, 0.01)
    cod = st.slider("COD (mg/L)", 300, 900, 550, 10)
    current = st.slider("Current (A)", 0.10, 0.60, 0.45, 0.01)

input_df = pd.DataFrame({
    "pH": [ph],
    "temperature_C": [temp],
    "voltage_V": [voltage],
    "COD_mg_L": [cod],
    "current_A": [current]
})

pred_h2 = float(model.predict(input_df)[0])

# Simple status rules based on the ranges described in the project presentation.
if 6.5 <= ph <= 7.0 and 0.2 <= voltage <= 0.8:
    status = "OPTIMAL RANGE"
elif ph < 6.5 or ph > 7.0:
    status = "CHECK pH"
else:
    status = "CHECK CONDITIONS"

c1, c2, c3, c4 = st.columns(4)
c1.metric("Predicted H₂", f"{pred_h2:.1f} mL")
c2.metric("pH", f"{ph:.1f}")
c3.metric("Voltage", f"{voltage:.2f} V")
c4.metric("Status", status)

st.divider()

left, right = st.columns(2)

with left:
    st.subheader("🤖 AI Prediction")
    st.write(
        "The XGBoost model estimates hydrogen production from pH, "
        "temperature, applied voltage, COD and current."
    )

    # Feature importance
    importance = pd.DataFrame({
        "Parameter": FEATURES,
        "Importance": model.feature_importances_
    }).sort_values("Importance", ascending=True)

    fig_imp = px.bar(
        importance,
        x="Importance",
        y="Parameter",
        orientation="h",
        title="AI Feature Importance"
    )
    st.plotly_chart(fig_imp, use_container_width=True)

with right:
    st.subheader("📊 Dataset Overview")
    fig = px.scatter(
        df,
        x="voltage_V",
        y="H2_mL",
        color="pH",
        hover_data=["temperature_C", "COD_mg_L", "current_A"],
        title="Sample Data: Voltage vs H₂ Production"
    )
    st.plotly_chart(fig, use_container_width=True)

st.divider()

st.subheader("🎯 AI-Based Operating Recommendation")

# Search a practical grid while keeping COD/current fixed at current user inputs.
best_h2 = -np.inf
best = None

for test_ph in np.arange(6.5, 7.01, 0.1):
    for test_voltage in np.arange(0.2, 0.801, 0.02):
        candidate = pd.DataFrame({
            "pH": [round(test_ph, 2)],
            "temperature_C": [temp],
            "voltage_V": [round(test_voltage, 2)],
            "COD_mg_L": [cod],
            "current_A": [current]
        })
        score = float(model.predict(candidate)[0])
        if score > best_h2:
            best_h2 = score
            best = candidate.iloc[0].to_dict()

r1, r2, r3, r4 = st.columns(4)
r1.metric("Recommended pH", f"{best['pH']:.1f}")
r2.metric("Recommended Voltage", f"{best['voltage_V']:.2f} V")
r3.metric("Temperature", f"{best['temperature_C']:.1f} °C")
r4.metric("Predicted H₂", f"{best_h2:.1f} mL")

st.info(
    "Demo recommendation only. The model is trained on synthetic sample data. "
    "For a real MEC controller, retrain it with experimentally measured/sensor data "
    "and validate the recommendations before applying them to hardware."
)

st.divider()

st.subheader("📈 H₂ Production Trend")
demo = df.copy().reset_index().rename(columns={"index": "Sample"})
fig_trend = px.line(
    demo,
    x="Sample",
    y="H2_mL",
    title="Sample H₂ Production Readings"
)
st.plotly_chart(fig_trend, use_container_width=True)

with st.expander("📋 View sample dataset"):
    st.dataframe(df, use_container_width=True)

with st.expander("🧠 Model evaluation"):
    X = df[FEATURES]
    y = df["H2_mL"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
    # Evaluate the loaded model on the held-out portion for a consistent demo.
    pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, pred)
    r2 = r2_score(y_test, pred)
    st.write(f"MAE: **{mae:.2f} mL**")
    st.write(f"R²: **{r2:.3f}**")
